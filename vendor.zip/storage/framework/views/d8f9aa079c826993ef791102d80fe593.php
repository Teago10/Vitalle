
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['active' => 'dashboard']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['active' => 'dashboard']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
        <aside class="fixed left-0 top-0 w-64 h-screen bg-[#232935] flex flex-col shrink-0">

            
            <div class="px-5 py-5 border-b border-white/10">
                <div class="text-white text-lg font-semibold">Vitalle</div>
                <div class="text-white/50 text-xs mt-0.5">
                    Cuidado que transforma
                </div>
            </div>

            
            <nav class="flex-1 px-3 py-2 flex flex-col gap-1 overflow-y-auto">

                <a href="<?php echo e(route('admin.paciente.index')); ?>"
                    class="flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm transition-colors
                    <?php echo e($active === 'cadastros' ? 'bg-[#5FA83D] text-white' : 'text-white/75 hover:bg-white/10 hover:text-white'); ?>">
                    <i class="ti ti-user-plus text-lg"></i>
                    Cadastros
                </a>

                <a href="<?php echo e(route('atendimento.index')); ?>"
                    class="flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm transition-colors
                    <?php echo e($active === 'atendimentos' ? 'bg-[#5FA83D] text-white' : 'text-white/75 hover:bg-white/10 hover:text-white'); ?>">
                    <i class="ti ti-calendar-event text-lg"></i>
                    Atendimentos
                </a>

                <a href="<?php echo e(route('avaliacao.index')); ?>"
                    class="flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm transition-colors
                    <?php echo e($active === 'avaliacoes' ? 'bg-[#5FA83D] text-white' : 'text-white/75 hover:bg-white/10 hover:text-white'); ?>">
                    <i class="ti ti-star text-lg"></i>
                    Avaliações
                </a>

                <div class="h-px bg-white/10 my-3"></div>

                <a  href="<?php echo e(route('suporte.index')); ?>"
                    class="flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm text-white/75 hover:bg-white/10 hover:text-white">
                    <i class="ti ti-headset text-lg"></i>
                    Suporte
                </a>

            </nav>

            
            <div class="p-3 border-t border-white/10">

                <a class="flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm text-white/75 hover:bg-white/10 hover:text-white">
                    <i class="ti ti-settings text-lg"></i>
                    Configurações
                </a>

                <button
                    class="w-full mt-2 flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm text-white/75 hover:bg-white/10 hover:text-white">
                    <i class="ti ti-logout text-lg"></i>
                    Sair
                </button>

            </div>

        </aside><?php /**PATH C:\xampp\htdocs\ProjetoVitalle\Vitalle\resources\views/components/sidebar.blade.php ENDPATH**/ ?>