<?php if (isset($component)) { $__componentOriginal41ae1e33d1abea5788c4e7ef6b2b71f1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal41ae1e33d1abea5788c4e7ef6b2b71f1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sistema','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sistema'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page-header','data' => ['title' => 'Central de Suporte','subtitle' => 'Estamos aqui para ajudar você.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Central de Suporte','subtitle' => 'Estamos aqui para ajudar você.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e)): ?>
<?php $attributes = $__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e; ?>
<?php unset($__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e)): ?>
<?php $component = $__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e; ?>
<?php unset($__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e); ?>
<?php endif; ?>

    <div class="p-6">
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h2 class="text-xl font-semibold text-gray-800 mb-2">
                Como podemos ajudar?
            </h2>

            <p class="text-gray-500 mb-6">
                Envie sua dúvida ou relate um problema para nossa equipe.
            </p>

            <?php if(session('sucesso')): ?>
                <div class="mb-4 rounded-lg bg-green-100 p-4 text-green-700">
                    <?php echo e(session('sucesso')); ?>

                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('suporte.armazenar')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="mb-4">
                    <label for="nome" class="block text-sm font-medium text-gray-700 mb-1">
                        Nome completo
                    </label>

                    <input type="text" name="nome" id="nome" value="<?php echo e(old('nome')); ?>" required
                        maxlength="150"
                        class="w-full rounded-lg border border-gray-300 px-4 py-3 focus:border-[#5FA83D] focus:ring-[#5FA83D]"
                        placeholder="Digite seu nome completo">

                    <?php $__errorArgs = ['nome'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label for="assunto" class="block text-sm font-medium text-gray-700 mb-1">
                        Assunto
                    </label>

                    <input type="text" name="assunto" id="assunto" value="<?php echo e(old('assunto')); ?>" required
                        maxlength="200"
                        class="w-full rounded-lg border border-gray-300 px-4 py-3 focus:border-[#5FA83D] focus:ring-[#5FA83D]"
                        placeholder="Ex.: Problema no cadastro">

                    <?php $__errorArgs = ['assunto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-6">
                    <label for="mensagem" class="block text-sm font-medium text-gray-700 mb-1">
                        Descrição
                    </label>

                    <textarea name="mensagem" id="mensagem" rows="5" required
                        class="w-full rounded-lg border border-gray-300 px-4 py-3 focus:border-[#5FA83D] focus:ring-[#5FA83D]"
                        placeholder="Descreva sua dúvida ou problema..."><?php echo e(old('mensagem')); ?></textarea>

                    <?php $__errorArgs = ['mensagem'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <button type="submit"
                    class="rounded-lg bg-[#5FA83D] px-6 py-3 font-medium text-white transition hover:bg-[#4b8b2f]">
                    Enviar solicitação
                </button>
            </form>
        </div>
    </div>


    <div class="px-6 pb-6">
        <div class="rounded-xl border border-gray-200 bg-white p-6 shadow-sm">

            <h2 class="mb-2 text-xl font-semibold text-gray-800">
                Perguntas frequentes
            </h2>

            <p class="mb-6 text-gray-500">
                Confira algumas respostas para as dúvidas mais comuns.
            </p>

            <div class="divide-y divide-gray-200">

                <details class="py-4">
                    <summary class="cursor-pointer font-medium text-gray-700 hover:text-[#5FA83D]">
                        Como posso entrar em contato com o suporte?
                    </summary>

                    <p class="mt-3 text-sm leading-6 text-gray-600">
                        Você pode enviar uma solicitação pelo formulário acima,
                        informando seu nome, o assunto e uma descrição detalhada
                        da sua dúvida ou problema.
                    </p>
                </details>

                <details class="py-4">
                    <summary class="cursor-pointer font-medium text-gray-700 hover:text-[#5FA83D]">
                        Como faço para acompanhar minha solicitação?
                    </summary>

                    <p class="mt-3 text-sm leading-6 text-gray-600">
                        As solicitações são registradas no sistema. A consulta
                        de histórico e o acompanhamento de status poderão ser
                        disponibilizados em uma próxima etapa.
                    </p>
                </details>

                <details class="py-4">
                    <summary class="cursor-pointer font-medium text-gray-700 hover:text-[#5FA83D]">
                        Quanto tempo demora para receber uma resposta?
                    </summary>

                    <p class="mt-3 text-sm leading-6 text-gray-600">
                        O prazo de resposta dependerá da organização da equipe
                        de suporte. Se necessário, informe a urgência no campo
                        de descrição da solicitação.
                    </p>
                </details>

                <details class="py-4">
                    <summary class="cursor-pointer font-medium text-gray-700 hover:text-[#5FA83D]">
                        Quais informações devo colocar na descrição?
                    </summary>

                    <p class="mt-3 text-sm leading-6 text-gray-600">
                        Explique o que aconteceu, em qual parte do Vitalle
                        ocorreu o problema e quais passos você realizou antes
                        de encontrar a dificuldade.
                    </p>
                </details>

            </div>
        </div>
    </div>


    <div class="px-6 pt-6 pb-6">
        <div class="rounded-xl border border-gray-200 bg-white p-6 shadow-sm">

            <h2 class="mb-2 text-xl font-semibold text-gray-800">
                Minhas solicitações
            </h2>

            <p class="mb-6 text-gray-500">
                Confira as solicitações registradas na Central de Suporte.
            </p>

            <?php if($solicitacoes->isEmpty()): ?>
                <p class="py-6 text-center text-gray-500">
                    Nenhuma solicitação registrada até o momento.
                </p>
            <?php else: ?>
                <div class="overflow-x-auto">
                    <table class="w-full text-left text-sm">
                        <thead>
                            <tr class="border-b border-gray-200 text-gray-500">
                                <th class="px-4 py-3 font-medium">Assunto</th>
                                <th class="px-4 py-3 font-medium">Data</th>
                                <th class="px-4 py-3 font-medium">Status</th>
                                <th class="px-4 py-3 font-medium">Ações</th>
                            </tr>
                        </thead>

                        <tbody class="divide-y divide-gray-100">
                            <?php $__currentLoopData = $solicitacoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $solicitacao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="px-4 py-4 font-medium text-gray-800">
                                        <?php echo e($solicitacao->assunto); ?>

                                    </td>

                                    <td class="px-4 py-4 text-gray-600">
                                        <?php echo e($solicitacao->created_at->format('d/m/Y H:i')); ?>

                                    </td>

                                    <td class="px-4 py-4">
                                        <span
                                            class="inline-flex rounded-full bg-yellow-100 px-3 py-1 text-xs font-medium text-yellow-800">
                                            <?php echo e($solicitacao->status); ?>

                                        </span>
                                    </td>

                                    <td class="px-4 py-4">
                                        <button type="button" id="botao-detalhes-suporte-<?php echo e($solicitacao->id); ?>"
                                            onclick="mostrarDetalhesSuporte(<?php echo e($solicitacao->id); ?>)"
                                            class="font-medium text-[#5FA83D] hover:text-[#4b8b2f]">
                                            Ver detalhes
                                        </button>
                                    </td>

                                </tr>

                                <tr id="detalhes-suporte-<?php echo e($solicitacao->id); ?>" class="hidden bg-gray-50">
                                    <td colspan="4" class="px-6 py-5">
                                        <div class="space-y-3">
                                            <div>
                                                <p class="text-sm font-semibold text-gray-700">Nome completo</p>
                                                <p class="text-sm text-gray-600">
                                                    <?php echo e($solicitacao->nome); ?>

                                                </p>
                                            </div>

                                            <div>
                                                <p class="text-sm font-semibold text-gray-700">Descrição</p>
                                                <p class="whitespace-pre-line text-sm text-gray-600">
                                                    <?php echo e($solicitacao->mensagem); ?>

                                                </p>
                                            </div>

                                            <div class="text-sm text-gray-500">
                                                Enviada em:
                                                <?php echo e($solicitacao->created_at->format('d/m/Y H:i')); ?>

                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>

            <?php endif; ?>

        </div>
    </div>


    <script>
    function mostrarDetalhesSuporte(id) {
        const detalhes = document.getElementById('detalhes-suporte-' + id);
        const botao = document.getElementById('botao-detalhes-suporte-' + id);

        if (detalhes && botao) {
            detalhes.classList.toggle('hidden');

            if (detalhes.classList.contains('hidden')) {
                botao.textContent = 'Ver detalhes';
            } else {
                botao.textContent = 'Ocultar detalhes';
            }
        }
    }
</script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal41ae1e33d1abea5788c4e7ef6b2b71f1)): ?>
<?php $attributes = $__attributesOriginal41ae1e33d1abea5788c4e7ef6b2b71f1; ?>
<?php unset($__attributesOriginal41ae1e33d1abea5788c4e7ef6b2b71f1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal41ae1e33d1abea5788c4e7ef6b2b71f1)): ?>
<?php $component = $__componentOriginal41ae1e33d1abea5788c4e7ef6b2b71f1; ?>
<?php unset($__componentOriginal41ae1e33d1abea5788c4e7ef6b2b71f1); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ProjetoVitalle\Vitalle\resources\views/suporte_page/suporte.blade.php ENDPATH**/ ?>