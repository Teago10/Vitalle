<?php if (isset($component)) { $__componentOriginal41ae1e33d1abea5788c4e7ef6b2b71f1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal41ae1e33d1abea5788c4e7ef6b2b71f1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sistema','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sistema'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="mx-auto flex h-[calc(100vh-2rem)] max-w-6xl flex-col overflow-hidden px-6">

        
        <main class="flex flex-1 items-center justify-center overflow-hidden">

            <div class="flex w-full -translate-y-4 flex-col items-center text-center">

                
                <div class="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-[#518364]/10">
                    <i class="ti ti-heart-handshake text-2xl text-[#518364]"></i>
                </div>

                
                <h1 class="text-2xl font-semibold tracking-tight text-[#232935] md:text-3xl">
                    Bem-vindo ao
                    <span class="text-[#518364]">Vitalle.</span>
                </h1>

                
                <p class="mt-3 max-w-md text-sm leading-6 text-gray-500">
                    Cuidado, organização e confiança em um só lugar.
                </p>

                
                <div class="mt-5 h-1 w-10 rounded-full bg-[#518364]"></div>

            </div>

        </main>

        
        <footer class="shrink-0 py-3 text-center text-xs text-gray-400">
            © <?php echo e(date('Y')); ?> Vitalle
        </footer>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal41ae1e33d1abea5788c4e7ef6b2b71f1)): ?>
<?php $attributes = $__attributesOriginal41ae1e33d1abea5788c4e7ef6b2b71f1; ?>
<?php unset($__attributesOriginal41ae1e33d1abea5788c4e7ef6b2b71f1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal41ae1e33d1abea5788c4e7ef6b2b71f1)): ?>
<?php $component = $__componentOriginal41ae1e33d1abea5788c4e7ef6b2b71f1; ?>
<?php unset($__componentOriginal41ae1e33d1abea5788c4e7ef6b2b71f1); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\ProjetoVitalle\Vitalle\resources\views/dashboard.blade.php ENDPATH**/ ?>