<img
    src="<?php echo e(asset('img/vitalleLogo.png')); ?>"
    alt="Vitalle"
    class="w-32 h-auto"><?php /**PATH C:\xampp\htdocs\ProjetoVitalle\Vitalle\resources\views/components/application-logo.blade.php ENDPATH**/ ?>