<?php if (isset($component)) { $__componentOriginal41ae1e33d1abea5788c4e7ef6b2b71f1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal41ae1e33d1abea5788c4e7ef6b2b71f1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sistema','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sistema'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="max-w-6xl mx-auto mt-0">
        <?php if (isset($component)) { $__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page-header','data' => ['title' => 'Atendimentos','subtitle' => 'Visualize e gerencie os atendimentos solicitados.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Atendimentos','subtitle' => 'Visualize e gerencie os atendimentos solicitados.']); ?>

            <a href="<?php echo e(route('atendimento.cadastro')); ?>"
                class="bg-[#5FA83D] hover:bg-[#4b8b2f] text-white px-5 py-3 rounded-lg flex items-center gap-2">

                <i class="ti ti-plus"></i>
                Novo Atendimento

            </a>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e)): ?>
<?php $attributes = $__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e; ?>
<?php unset($__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e)): ?>
<?php $component = $__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e; ?>
<?php unset($__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e); ?>
<?php endif; ?>


        
        <?php if(session('sucesso')): ?>
            <div class="mb-6 bg-green-100 border border-green-300 text-green-800 px-5 py-4 rounded-xl">
                <?php echo e(session('sucesso')); ?>

            </div>
        <?php endif; ?>


        <div class="bg-white rounded-3xl shadow-lg p-8">

            <?php if($atendimentos->isEmpty()): ?>

                <div class="text-center py-12">

                    <i class="ti ti-calendar-off text-5xl text-gray-300"></i>

                    <h3 class="mt-4 text-lg font-semibold text-gray-700">
                        Nenhum atendimento encontrado
                    </h3>

                    <p class="mt-2 text-gray-500">
                        Ainda não existem atendimentos cadastrados.
                    </p>

                    <a href="<?php echo e(route('atendimento.cadastro')); ?>"
                        class="inline-flex items-center gap-2 mt-6 bg-[#5FA83D] hover:bg-[#4b8b2f] text-white px-5 py-3 rounded-lg">

                        <i class="ti ti-plus"></i>
                        Solicitar Atendimento

                    </a>

                </div>
            <?php else: ?>
                <div class="overflow-x-auto">

                    <table class="w-full">

                        <thead>
                            <tr class="border-b border-gray-200">
                                <th class="text-left py-4 px-3">Paciente</th>
                                <th class="text-left py-4 px-3">Data</th>
                                <th class="text-left py-4 px-3">Horário</th>
                                <th class="text-left py-4 px-3">Jornada</th>
                                <th class="text-left py-4 px-3">Cuidador</th>
                                <th class="text-left py-4 px-3">Valor</th>
                                <th class="text-left py-4 px-3">Status</th>
                                <th class="text-left py-4 px-3 pl-11">Ações</th>
                            </tr>
                        </thead>

                        <tbody>

                            <?php $__currentLoopData = $atendimentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atendimento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="border-b border-gray-100 hover:bg-gray-50">

                                    <td class="py-4 px-3 font-medium text-gray-800">

                                        <div>
                                            <?php echo e($atendimento->paciente->nome); ?>

                                        </div>

                                        <button type="button"
                                            onclick="mostrarMaisPaciente(<?php echo e($atendimento->id); ?>, this)"
                                            class="mt-1 text-sm text-[#5FA83D] hover:text-[#4b8b2f] font-medium">
                                            Ver mais
                                        </button>

                                    </td>

                                    <td class="py-4 px-3 text-gray-600">
                                        <?php echo e(\Carbon\Carbon::parse($atendimento->data_atendimento)->format('d/m/Y')); ?>

                                    </td>

                                    <td class="py-4 px-3 text-gray-600">
                                        <?php echo e(substr($atendimento->horario_inicio, 0, 5)); ?>

                                        -
                                        <?php echo e(substr($atendimento->horario_fim, 0, 5)); ?>

                                    </td>

                                    <td class="py-4 px-3 text-gray-600">
                                        <?php echo e($atendimento->tipo_jornada); ?>

                                    </td>

                                    <td class="py-4 px-3 text-gray-600">

                                        <?php if($atendimento->cuidador): ?>
                                            <?php echo e($atendimento->cuidador->nome); ?>

                                        <?php else: ?>
                                            <span class="text-gray-400">
                                                Aguardando cuidador
                                            </span>
                                        <?php endif; ?>

                                    </td>

                                    <td class="py-4 px-3 text-gray-600">
                                        R$ <?php echo e(number_format($atendimento->valor, 2, ',', '.')); ?>

                                    </td>

                                    <td class="py-4 px-3">

                                        <?php if($atendimento->status === 'ABERTO'): ?>
                                            <span class="bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-sm">
                                                Aberto
                                            </span>
                                        <?php elseif($atendimento->status === 'ACEITO'): ?>
                                            <span class="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm">
                                                Aceito
                                            </span>
                                        <?php elseif($atendimento->status === 'EM_ANDAMENTO'): ?>
                                            <span class="bg-purple-100 text-purple-800 px-3 py-1 rounded-full text-sm">
                                                Em andamento
                                            </span>
                                        <?php elseif($atendimento->status === 'CONCLUIDO'): ?>
                                            <span class="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm">
                                                Concluído
                                            </span>
                                        <?php elseif($atendimento->status === 'CANCELADO'): ?>
                                            <span class="bg-red-100 text-red-800 px-3 py-1 rounded-full text-sm">
                                                Cancelado
                                            </span>
                                        <?php else: ?>
                                            <span class="bg-gray-100 text-gray-800 px-3 py-1 rounded-full text-sm">
                                                <?php echo e($atendimento->status); ?>

                                            </span>
                                        <?php endif; ?>

                                    </td>

                                    
                                    <td class="py-4 px-3">
                                        <div class="flex flex-col items-center gap-2">

                                            <?php if($atendimento->status === 'ABERTO'): ?>
                                                <a href="<?php echo e(route('atendimento.editar', $atendimento->id)); ?>"
                                                    class="inline-flex items-center justify-center gap-1 w-28 px-3 py-2 rounded-lg bg-blue-100 hover:bg-blue-200 text-blue-800 text-sm font-medium">
                                                    <i class="ti ti-edit"></i>
                                                    Editar
                                                </a>
                                            <?php endif; ?>

                                            <?php if($atendimento->status === 'ABERTO'): ?>
                                                <form action="<?php echo e(route('atendimento.cancelar', $atendimento->id)); ?>"
                                                    method="POST" class="w-28"
                                                    onsubmit="return confirm('Tem certeza de que deseja cancelar este atendimento?');">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PATCH'); ?>

                                                    <button type="submit"
                                                        class="inline-flex items-center justify-center gap-1 w-full px-3 py-2 rounded-lg bg-red-100 hover:bg-red-200 text-red-800 text-sm font-medium">
                                                        <i class="ti ti-x"></i>
                                                        Cancelar
                                                    </button>
                                                </form>
                                            <?php endif; ?>

                                        </div>
                                    </td>

                                </tr>

                                <tr id="maisPaciente-<?php echo e($atendimento->id); ?>" class="hidden">

                                    <td colspan="8" class="px-6 py-5 bg-gray-50">

                                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">

                                            <div>
                                                <p class="text-sm text-gray-500">
                                                    Data de nascimento
                                                </p>

                                                <p class="font-medium text-gray-800">
                                                    <?php echo e($atendimento->paciente->data_nascimento
                                                        ? \Carbon\Carbon::parse($atendimento->paciente->data_nascimento)->format('d/m/Y')
                                                        : 'Não informado'); ?>

                                                </p>
                                            </div>


                                            <div>
                                                <p class="text-sm text-gray-500">
                                                    Comorbidade
                                                </p>

                                                <p class="font-medium text-gray-800">
                                                    <?php echo e($atendimento->paciente->comorbidade ?: 'Não informado'); ?>

                                                </p>
                                            </div>


                                            <div>
                                                <p class="text-sm text-gray-500">
                                                    Condição física
                                                </p>

                                                <p class="font-medium text-gray-800">
                                                    <?php echo e($atendimento->paciente->condicao_fisica ?: 'Não informado'); ?>

                                                </p>
                                            </div>


                                            <div>
                                                <p class="text-sm text-gray-500">
                                                    Usa fraldas?
                                                </p>

                                                <p class="font-medium text-gray-800">

                                                    <?php if($atendimento->paciente->usa_fraldas == 1): ?>
                                                        Sim
                                                    <?php elseif($atendimento->paciente->usa_fraldas == 0): ?>
                                                        Não
                                                    <?php else: ?>
                                                        Não informado
                                                    <?php endif; ?>

                                                </p>
                                            </div>


                                            <div>
                                                <p class="text-sm text-gray-500">
                                                    Medicação
                                                </p>

                                                <p class="font-medium text-gray-800">
                                                    <?php echo e($atendimento->paciente->medicacao ?: 'Não informado'); ?>

                                                </p>
                                            </div>


                                            <div>
                                                <p class="text-sm text-gray-500">
                                                    Horário da medicação
                                                </p>

                                                <p class="font-medium text-gray-800">
                                                    <?php echo e($atendimento->paciente->horario_medicacao ?: 'Não informado'); ?>

                                                </p>
                                            </div>

                                        </div>

                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>

                    </table>

                </div>

            <?php endif; ?>

        </div>

    </div>

    <script>
        function mostrarMaisPaciente(id, botao) {
            const informacoes =
                document.getElementById('maisPaciente-' + id);

            if (informacoes.classList.contains('hidden')) {
                informacoes.classList.remove('hidden');
                botao.innerHTML = 'Ver menos';
            } else {
                informacoes.classList.add('hidden');
                botao.innerHTML = 'Ver mais';
            }
        }
    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal41ae1e33d1abea5788c4e7ef6b2b71f1)): ?>
<?php $attributes = $__attributesOriginal41ae1e33d1abea5788c4e7ef6b2b71f1; ?>
<?php unset($__attributesOriginal41ae1e33d1abea5788c4e7ef6b2b71f1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal41ae1e33d1abea5788c4e7ef6b2b71f1)): ?>
<?php $component = $__componentOriginal41ae1e33d1abea5788c4e7ef6b2b71f1; ?>
<?php unset($__componentOriginal41ae1e33d1abea5788c4e7ef6b2b71f1); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ProjetoVitalle\Vitalle\resources\views/atendimento/index.blade.php ENDPATH**/ ?>