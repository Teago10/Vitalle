<?php if (isset($component)) { $__componentOriginal41ae1e33d1abea5788c4e7ef6b2b71f1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal41ae1e33d1abea5788c4e7ef6b2b71f1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sistema','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sistema'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

<div class="max-w-6xl mx-auto">

    <?php if (isset($component)) { $__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page-header','data' => ['title' => 'Editar Paciente','subtitle' => 'Altere os dados do paciente e salve as informações atualizadas.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Editar Paciente','subtitle' => 'Altere os dados do paciente e salve as informações atualizadas.']); ?>
        <a
            href="<?php echo e(route('admin.paciente.index')); ?>"
            class="bg-gray-200 hover:bg-gray-300 text-gray-800 px-5 py-3 rounded-lg flex items-center gap-2"
        >
            <i class="ti ti-arrow-left"></i>
            Voltar
        </a>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e)): ?>
<?php $attributes = $__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e; ?>
<?php unset($__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e)): ?>
<?php $component = $__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e; ?>
<?php unset($__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e); ?>
<?php endif; ?>

    <div class="bg-white rounded-3xlagora  shadow-lg p-8">

        
        <?php if($errors->any()): ?>

            <div class="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-500">

                <p class="font-semibold mb-2">
                    Verifique os erros abaixo:
                </p>

                <ul class="list-disc list-inside">

                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $erro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($erro); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>

            </div>

        <?php endif; ?>

        <form
            action="<?php echo e(route('profile.paciente.atualizar', $paciente->id)); ?>"
            method="POST"
        >

            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

                
                <div>

                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Nome
                    </label>

                    <input
                        type="text"
                        name="nome"
                        value="<?php echo e(old('nome', $paciente->nome)); ?>"
                        class="w-full rounded-lg border-gray-300 focus:border-[#5FA83D] focus:ring-[#5FA83D]"
                        required
                    >

                    <?php $__errorArgs = ['nome'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1">
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>


                
                <div>

                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Responsável
                    </label>

                    <select
                        name="id_responsavel"
                        class="w-full rounded-lg border-gray-300 focus:border-[#5FA83D] focus:ring-[#5FA83D]"
                        required
                    >

                        <option value="">
                            Selecione um responsável
                        </option>

                        <?php $__currentLoopData = $responsaveis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $nome): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <option
                                value="<?php echo e($id); ?>"
                                <?php echo e(old('id_responsavel', $paciente->id_responsavel) == $id ? 'selected' : ''); ?>

                            >
                                <?php echo e($nome); ?>

                            </option>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>

                    <?php $__errorArgs = ['id_responsavel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1">
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>


                
                <div>

                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Data de nascimento
                    </label>

                    <input
                        type="date"
                        name="data_nascimento"
                        value="<?php echo e(old('data_nascimento', $paciente->data_nascimento)); ?>"
                        class="w-full rounded-lg border-gray-300 focus:border-[#5FA83D] focus:ring-[#5FA83D]"
                        required
                    >

                    <?php $__errorArgs = ['data_nascimento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1">
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>


                
                <div>

                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        E-mail
                    </label>

                    <input
                        type="email"
                        name="email"
                        value="<?php echo e(old('email', $paciente->email)); ?>"
                        class="w-full rounded-lg border-gray-300 focus:border-[#5FA83D] focus:ring-[#5FA83D]"
                        required
                    >

                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1">
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>


                
                <div>

                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Comorbidade
                    </label>

                    <input
                        type="text"
                        name="comorbidade"
                        value="<?php echo e(old('comorbidade', $paciente->comorbidade)); ?>"
                        class="w-full rounded-lg border-gray-300 focus:border-[#5FA83D] focus:ring-[#5FA83D]"
                    >

                    <?php $__errorArgs = ['comorbidade'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1">
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>


                
                <div>

                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Condição Física
                    </label>

                    <input
                        type="text"
                        name="condicao_fisica"
                        value="<?php echo e(old('condicao_fisica', $paciente->condicao_fisica)); ?>"
                        class="w-full rounded-lg border-gray-300 focus:border-[#5FA83D] focus:ring-[#5FA83D]"
                    >

                    <?php $__errorArgs = ['condicao_fisica'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1">
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>


                
                <div>

                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Medicação
                    </label>

                    <input
                        type="text"
                        name="medicacao"
                        value="<?php echo e(old('medicacao', $paciente->medicacao)); ?>"
                        class="w-full rounded-lg border-gray-300 focus:border-[#5FA83D] focus:ring-[#5FA83D]"
                    >

                    <?php $__errorArgs = ['medicacao'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1">
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>


                
                <div>

                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Horário da Medicação
                    </label>

                    <input
                        type="text"
                        name="horario_medicacao"
                        value="<?php echo e(old('horario_medicacao', $paciente->horario_medicacao)); ?>"
                        class="w-full rounded-lg border-gray-300 focus:border-[#5FA83D] focus:ring-[#5FA83D]"
                    >

                    <?php $__errorArgs = ['horario_medicacao'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1">
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>


                
                <div>

                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        CEP
                    </label>

                    <input
                        type="text"
                        id="cep"
                        name="cep"
                        value="<?php echo e(old('cep', $paciente->cep)); ?>"
                        class="w-full rounded-lg border-gray-300 focus:border-[#5FA83D] focus:ring-[#5FA83D]"
                        required
                    >

                    <?php $__errorArgs = ['cep'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1">
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>


                
                <div>

                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Rua
                    </label>

                    <input
                        type="text"
                        id="rua"
                        name="rua"
                        value="<?php echo e(old('rua', $paciente->rua)); ?>"
                        class="w-full rounded-lg border-gray-300 focus:border-[#5FA83D] focus:ring-[#5FA83D]"
                        required
                    >

                    <?php $__errorArgs = ['rua'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1">
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>


                
                <div>

                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Número
                    </label>

                    <input
                        type="text"
                        name="numero"
                        value="<?php echo e(old('numero', $paciente->numero)); ?>"
                        class="w-full rounded-lg border-gray-300 focus:border-[#5FA83D] focus:ring-[#5FA83D]"
                        required
                    >

                    <?php $__errorArgs = ['numero'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1">
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>


                
                <div>

                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Complemento
                    </label>

                    <input
                        type="text"
                        name="complemento"
                        value="<?php echo e(old('complemento', $paciente->complemento)); ?>"
                        class="w-full rounded-lg border-gray-300 focus:border-[#5FA83D] focus:ring-[#5FA83D]"
                    >

                    <?php $__errorArgs = ['complemento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1">
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>


                
                <div>

                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Bairro
                    </label>

                    <input
                        type="text"
                        id="bairro"
                        name="bairro"
                        value="<?php echo e(old('bairro', $paciente->bairro)); ?>"
                        class="w-full rounded-lg border-gray-300 focus:border-[#5FA83D] focus:ring-[#5FA83D]"
                        required
                    >

                    <?php $__errorArgs = ['bairro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1">
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>


                
                <div>

                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Cidade
                    </label>

                    <input
                        type="text"
                        id="cidade"
                        name="cidade"
                        value="<?php echo e(old('cidade', $paciente->cidade)); ?>"
                        class="w-full rounded-lg border-gray-300 focus:border-[#5FA83D] focus:ring-[#5FA83D]"
                        required
                    >

                    <?php $__errorArgs = ['cidade'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1">
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>


                
                <div>

                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Estado
                    </label>

                    <input
                        type="text"
                        id="estado"
                        name="estado"
                        value="<?php echo e(old('estado', $paciente->estado)); ?>"
                        class="w-full rounded-lg border-gray-300 focus:border-[#5FA83D] focus:ring-[#5FA83D]"
                        required
                    >

                    <?php $__errorArgs = ['estado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1">
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>


                
                <div class="flex items-center gap-3 mt-8">

                    <input
                        type="checkbox"
                        id="usa_fraldas"
                        name="usa_fraldas"
                        value="1"
                        <?php echo e(old('usa_fraldas', $paciente->usa_fraldas) ? 'checked' : ''); ?>

                        class="rounded border-gray-300 text-[#5FA83D] focus:ring-[#5FA83D]"
                    >

                    <label for="usa_fraldas">
                        Usa fraldas
                    </label>

                </div>

            </div>


            
            <div class="flex justify-end gap-4 mt-10">

                <a
                    href="<?php echo e(route('admin.paciente.index')); ?>"
                    class="px-6 py-3 rounded-lg bg-gray-200 hover:bg-gray-300"
                >
                    Cancelar
                </a>

                <button
                    type="submit"
                    class="px-6 py-3 rounded-lg bg-[#5FA83D] hover:bg-[#4b8b2f] text-white"
                >
                    Salvar Alterações
                </button>

            </div>

        </form>

    </div>

</div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal41ae1e33d1abea5788c4e7ef6b2b71f1)): ?>
<?php $attributes = $__attributesOriginal41ae1e33d1abea5788c4e7ef6b2b71f1; ?>
<?php unset($__attributesOriginal41ae1e33d1abea5788c4e7ef6b2b71f1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal41ae1e33d1abea5788c4e7ef6b2b71f1)): ?>
<?php $component = $__componentOriginal41ae1e33d1abea5788c4e7ef6b2b71f1; ?>
<?php unset($__componentOriginal41ae1e33d1abea5788c4e7ef6b2b71f1); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\ProjetoVitalle\Vitalle\resources\views/editar.blade.php ENDPATH**/ ?>