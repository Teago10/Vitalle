<?php if (isset($component)) { $__componentOriginal41ae1e33d1abea5788c4e7ef6b2b71f1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal41ae1e33d1abea5788c4e7ef6b2b71f1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sistema','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sistema'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="max-w-6xl mx-auto">



        <?php if (isset($component)) { $__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page-header','data' => ['title' => 'Pacientes','subtitle' => 'Gerencie todos os pacientes cadastrados.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Pacientes','subtitle' => 'Gerencie todos os pacientes cadastrados.']); ?>

            <a href="<?php echo e(route('profile.paciente.cadastrar')); ?>"
                class="bg-[#5FA83D] hover:bg-[#4b8b2f] text-white px-5 py-3 rounded-lg flex items-center gap-2">

                <i class="ti ti-plus"></i>

                Novo Paciente

            </a>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e)): ?>
<?php $attributes = $__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e; ?>
<?php unset($__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e)): ?>
<?php $component = $__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e; ?>
<?php unset($__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e); ?>
<?php endif; ?>

        <div class="bg-white rounded-3xl shadow-lg overflow-hidden">

            <table class="w-full">

                <thead class="bg-gray-100">
                    <tr>
                        <th class="p-4 text-left">Nome</th>
                        <th class="p-4 text-left">Data Nascimento</th>
                        <th class="p-4 text-left">Email</th>
                        <th class="p-4 text-left">Responsável</th>
                        <th class="p-4 text-center">Ações</th>
                    </tr>
                </thead>

                <tbody>

                    <?php $__empty_1 = true; $__currentLoopData = $paciente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="border-t hover:bg-gray-50">

                            <td class="p-4"><?php echo e($p->nome); ?></td>

                            <td class="p-4">
                                <?php echo e(\Carbon\Carbon::parse($p->data_nascimento)->format('d/m/Y')); ?>

                            </td>

                            <td class="p-4">
                                <?php echo e($p->email); ?>

                            </td>

                            <td class="p-4">
                                <?php echo e($p->responsavel->nome ?? '-'); ?>

                            </td>

                            <td class="p-4 text-center">

                                <a href="<?php echo e(route('profile.paciente.editar', $p->id)); ?>">
                                <button class="text-blue-700 hover:text-blue-800">
                                    <i class="ti ti-edit"></i> Editar
                                </button>
                            </a>


                                <form action="<?php echo e(route('profile.paciente.excluir', $p->id)); ?>" method="POST">

                                        <?php echo method_field('delete'); ?>
                                        <?php echo csrf_field(); ?>

                                        <button type="submit" class="text-red-700 hover:text-red-800" 
                                        onclick="return confirm('Deseja realmente excluir o registro?')">
                                            Excluir
                                    </button>
                                </form>

                            </td>

                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <tr>
                            <td colspan="5" class="text-center text-slate-400 px-5 py-3.5">
                                <p>Nenhum paciente cadastrado</p>
                            </td>
                        </tr>
                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal41ae1e33d1abea5788c4e7ef6b2b71f1)): ?>
<?php $attributes = $__attributesOriginal41ae1e33d1abea5788c4e7ef6b2b71f1; ?>
<?php unset($__attributesOriginal41ae1e33d1abea5788c4e7ef6b2b71f1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal41ae1e33d1abea5788c4e7ef6b2b71f1)): ?>
<?php $component = $__componentOriginal41ae1e33d1abea5788c4e7ef6b2b71f1; ?>
<?php unset($__componentOriginal41ae1e33d1abea5788c4e7ef6b2b71f1); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ProjetoVitalle\Vitalle\resources\views/paciente.blade.php ENDPATH**/ ?>