<?php if (isset($component)) { $__componentOriginal41ae1e33d1abea5788c4e7ef6b2b71f1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal41ae1e33d1abea5788c4e7ef6b2b71f1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sistema','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sistema'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="max-w-6xl mx-auto">

        <?php if (isset($component)) { $__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page-header','data' => ['title' => 'Avaliação dos Cuidadores','subtitle' => 'Avalie o atendimento realizado pelo cuidador.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Avaliação dos Cuidadores','subtitle' => 'Avalie o atendimento realizado pelo cuidador.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e)): ?>
<?php $attributes = $__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e; ?>
<?php unset($__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e)): ?>
<?php $component = $__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e; ?>
<?php unset($__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e); ?>
<?php endif; ?>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">

            <?php $__currentLoopData = $cuidadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuidador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white rounded-3xl shadow-lg overflow-hidden">

                    
                    <div class="h-56 bg-gray-200">

                        <img src="https://i.pravatar.cc/500?u=<?php echo e($cuidador->id); ?>" alt="Foto de <?php echo e($cuidador->nome); ?>"
                            class="w-full h-full object-cover">

                    </div>


                    
                    <div class="p-6">

                        <h2 class="text-xl font-semibold text-gray-800">
                            <?php echo e($cuidador->nome); ?>

                        </h2>

                        <p class="text-sm text-gray-500 mt-1">
                            <?php echo e($cuidador->qualificacao ?? 'Cuidador de idosos'); ?>

                        </p>

                        <p class="text-sm text-gray-600 mt-4">
                            Avalie o atendimento realizado por este cuidador.
                        </p>


                        
                        <div class="mt-6" data-avaliacao data-cuidador="<?php echo e($cuidador->id); ?>"
                            data-nota="<?php echo e($avaliacoes->get($cuidador->id)->nota ?? 0); ?>">

                            <p class="text-sm font-medium text-gray-700 mb-2">
                                Avalie este cuidador
                            </p>

                            <div class="flex gap-1">

                                <?php for($i = 1; $i <= 5; $i++): ?>
                                    <button type="button" class="estrela text-3xl text-gray-300 transition"
                                        data-valor="<?php echo e($i); ?>">
                                        ★
                                    </button>
                                <?php endfor; ?>

                            </div>

                        </div>

                    </div>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </div>


    
    <div id="aviso-avaliacao"
        class="fixed bottom-6 right-6 bg-[#232935] text-white px-5 py-3 rounded-xl shadow-lg text-sm font-medium z-50 opacity-0 translate-y-[10px] pointer-events-none transition-all duration-300">
        Avaliação selecionada
    </div>


    
    <script>
        document.querySelectorAll('[data-avaliacao]').forEach(function(avaliacao) {

            const estrelas = avaliacao.querySelectorAll('.estrela');

            const idCuidador = avaliacao.dataset.cuidador;
            const notaSalva = Number(avaliacao.dataset.nota);

            if (notaSalva > 0) {
                atualizarEstrelas(estrelas, notaSalva);
            }


            estrelas.forEach(function(estrela) {

                estrela.addEventListener('click', function(evento) {

                    const valor = Number(this.dataset.valor);

                    const largura = this.offsetWidth;

                    const posicaoX = evento.offsetX;

                    let nota;


                    // Clique na metade esquerda
                    if (posicaoX < largura / 2) {

                        nota = valor - 0.5;

                    }

                    // Clique na metade direita
                    else {

                        nota = valor;

                    }


                    // Atualiza visualmente as estrelas
                    atualizarEstrelas(estrelas, nota);


                    // Salva a avaliação
                    salvarAvaliacao(idCuidador, nota);

                });

            });

        });


        function atualizarEstrelas(estrelas, nota) {

            estrelas.forEach(function(estrela) {

                const valorEstrela =
                    Number(estrela.dataset.valor);


                // Limpa tudo
                estrela.classList.remove(
                    'text-yellow-400',
                    'text-gray-300'
                );

                estrela.style.background = '';

                estrela.style.webkitBackgroundClip = '';

                estrela.style.webkitTextFillColor = '';


                // Estrela cheia
                if (valorEstrela <= nota) {

                    estrela.classList.add(
                        'text-yellow-400'
                    );

                }


                // Meia estrela
                else if (valorEstrela - 0.5 === nota) {

                    estrela.style.background =
                        'linear-gradient(90deg, #facc15 50%, #d1d5db 50%)';

                    estrela.style.webkitBackgroundClip =
                        'text';

                    estrela.style.webkitTextFillColor =
                        'transparent';

                }


                // Estrela vazia
                else {

                    estrela.classList.add(
                        'text-gray-300'
                    );

                }

            });

        }


        function salvarAvaliacao(idCuidador, nota) {

            fetch('<?php echo e(route('avaliacao.salvar')); ?>', {

                    method: 'POST',

                    headers: {

                        'Content-Type': 'application/json',

                        'Accept': 'application/json',

                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'

                    },

                    body: JSON.stringify({

                        id_cuidador: idCuidador,

                        nota: nota

                    })

                })

                .then(function(resposta) {

                    if (!resposta.ok) {

                        throw new Error(
                            'Erro HTTP: ' + resposta.status
                        );

                    }

                    return resposta.json();

                })

                .then(function(dados) {

                    if (dados.sucesso) {

                        mostrarAviso(
                            'Avaliação salva: ' +
                            nota.toFixed(1).replace('.', ',') +
                            ' estrelas'
                        );

                    }

                })

                .catch(function(erro) {

                    console.error(
                        'Erro ao salvar avaliação:',
                        erro
                    );

                    mostrarAviso(
                        'Não foi possível salvar a avaliação.'
                    );

                });

        }


        function mostrarAviso(mensagem) {

            const aviso =
                document.getElementById('aviso-avaliacao');


            aviso.textContent = mensagem;


            // Mostra o aviso
            aviso.classList.remove(
                'opacity-0',
                'translate-y-[10px]'
            );


            // Cancela o timer anterior
            clearTimeout(window.timerAviso);


            // Esconde depois de 2 segundos
            window.timerAviso = setTimeout(function() {

                aviso.classList.add(
                    'opacity-0',
                    'translate-y-[10px]'
                );

            }, 2000);

        }
    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal41ae1e33d1abea5788c4e7ef6b2b71f1)): ?>
<?php $attributes = $__attributesOriginal41ae1e33d1abea5788c4e7ef6b2b71f1; ?>
<?php unset($__attributesOriginal41ae1e33d1abea5788c4e7ef6b2b71f1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal41ae1e33d1abea5788c4e7ef6b2b71f1)): ?>
<?php $component = $__componentOriginal41ae1e33d1abea5788c4e7ef6b2b71f1; ?>
<?php unset($__componentOriginal41ae1e33d1abea5788c4e7ef6b2b71f1); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ProjetoVitalle\Vitalle\resources\views/avaliacao/avaliacao.blade.php ENDPATH**/ ?>